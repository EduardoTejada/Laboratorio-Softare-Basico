#!/bin/bash

# tira leitura de teste.txt
chmod a-r webspace_para_testes/teste.txt

# tira execução de dir
chmod a-x webspace_para_testes/dir

# tira leitura dos arquivos específicos
chmod a-r webspace_para_testes/dir3/index.html
chmod a-r webspace_para_testes/dir4/index.html
chmod a-r webspace_para_testes/dir4/welcome.html

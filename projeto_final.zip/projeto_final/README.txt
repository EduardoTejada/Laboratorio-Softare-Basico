# Servidor Multithread

## Compilação
make

## Execução
./servidor_multi_thread [endereco_IP] [porta] [max_threads]
./servidor_multi_thread 0.0.0.0 3500 8
